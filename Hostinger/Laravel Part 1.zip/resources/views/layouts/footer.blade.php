<div class="d-flex bg-black justify-content-center align-items-center p-3 text-white">
  <div>
      © Copyright Poltekbang 2022
  </div>
</div>
