
<?php $__env->startSection('ats-message', 'active'); ?>
<?php $__env->startSection('content'); ?>

<style>
    @media  screen and (max-width: 420px) {
        .custom {
            display: flex !important;
            flex-direction: column !important;
        }

        .custom .col-2,
        .custom .col-3 {
            width: 100%;
        }

        .buttons {
            display: flex !important;
            /* background-color: red; */
            justify-content: center !important;
            margin-top: 25px !important;
            width: 100% !important;
            gap: 10px !important;
        }
    }
</style>

<link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<div class="position-relative w-100">
    <div class="container mt-5" style="margin-bottom: 20rem;">
        <div class="row justify-content-center mb-5">
            <div class="col">
                <div class="card border-0 shadow" style="border-radius: 13px;">
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('searchPost')); ?>" style="font-family: 'Poppins', sans-serif;">
                            <?php echo csrf_field(); ?>
                            <div class="row align-items-center p-3">
                                <div class="col">
                                    <h3 style="text-align: center">Search ATS Message</h3>
                                    <div class="row mb-3 custom">
                                        <div class="col">
                                            <label for="msg-type" class="col-md-4 mb-0 col-form-label"><?php echo e(__('Type Message')); ?></label>
                                            <select name="msg-type" id="msg-type" class="p-2 rounded form-select">
                                                <option value="FPL">FPL</option>
                                                <option value="FREETEXT">FREETEXT</option>
                                                <option value="CHG">CHG</option>
                                                <option value="DLA">DLA</option>
                                                <option value="CNL">CNL</option>
                                                <option value="DEP">DEP</option>
                                                <option value="ARR">ARR</option>
                                            </select>
                                        </div>
                                        <div class="col">
                                            <label for="originator" class="col-md-4 mb-0 col-form-label"><?php echo e(__('Originator')); ?></label>
                                            <input name="originator" id="originator" class="p-2 rounded form-control">
                                        </div>
                                        <div class="col">
                                            <label for="aircraft-id" class="col-md-4 mb-0 col-form-label"><?php echo e(__('Aircraft ID')); ?></label>
                                            <input name="aircraft-id" id="aircraft-id" class="p-2 rounded form-control">
                                        </div>
                                        <div class="col">
                                            <label for="dep" class="col-md-4 mb-0 col-form-label"><?php echo e(__('DEP')); ?></label>
                                            <input name="dep" id="dep" class="p-2 rounded form-control">
                                        </div>
                                        <div class="col">
                                            <label for="dest" class="col-md-4 mb-0 col-form-label"><?php echo e(__('DEST')); ?></label>
                                            <input name="dest" id="dest" class="p-2 rounded form-control">
                                        </div>
                                        <div class="col">
                                            <label for="etd" class="col-md-4 mb-0 col-form-label"><?php echo e(__('ETD')); ?></label>
                                            <input name="etd" id="etd" class="p-2 rounded form-control">
                                        </div>
                                        <div class="col">
                                            <label for="to" class="col-md-4 mb-0 col-form-label"><?php echo e(__('TO')); ?></label>
                                            <input name="to" id="to" class="p-2 rounded form-control">
                                        </div>
                                    </div>
                                    <div class="row mb-3 custom">
                                        <div class="col-2">
                                            <label for="dest" class="col-md-4 mb-0 col-form-label"><?php echo e(__('ARR')); ?></label>
                                            <input name="arr" id="arr" class="p-2 rounded form-control">
                                        </div>
                                        <div class="col-2">
                                            <label for="ata" class="col-md-4 mb-0 col-form-label"><?php echo e(__('ATA')); ?></label>
                                            <input name="ata" id="ata" class="p-2 rounded form-control">
                                        </div>
                                        
                                        <div class="col-3">
                                            <label for="freetext" class="me-2 mb-0 col-form-label"><?php echo e(__('Freetext ATS')); ?></label>
                                            <input name="freetext" id="freetext" class="p-2 rounded form-control">
                                        </div>
                                    </div>
                                    <div class="row mb-3 custom">
                                        <div class="col-2 d-inline-flex align-items-center me-4">
                                            <label for="dof" class="me-2 mb-0 col-form-label"><?php echo e(__('DOF')); ?></label>
                                            <input name="dof" id="dof" type="date" class="p-2 rounded form-control">
                                        </div>
                                        <div class="col-2 d-inline-flex align-items-center me-4">
                                            <label for="reg" class="me-2 mb-0 col-form-label"><?php echo e(__('REG')); ?></label>
                                            <input name="reg" id="reg" class="p-2 rounded form-control">
                                        </div>
                                        <div class="col-3 d-inline-flex align-items-center">
                                            <label for="route" class="me-2 mb-0 col-form-label"><?php echo e(__('Route')); ?></label>
                                            <input name="route" id="route" class="p-2 rounded form-control">
                                        </div>
                                    </div>
                                    <div class="row mb-3 custom">
                                        <div class="col-3 d-inline-flex align-items-center me-4">
                                            <label for="type" class="me-2 mb-0 col-form-label"><?php echo e(__('Type of Flight')); ?></label>
                                            <select name="type" id="type" class="p-2 rounded form-select text-uppercase">
                                                <option value="S">Schedule</option>
                                                <option value="N">Non schedule</option>
                                                <option value="">-- All types --</option>
                                            </select>
                                        </div>
                                        <div class="col-3 d-inline-flex align-items-center me-4">
                                            <label for="group" class="me-2 mb-0 col-form-label"><?php echo e(__('Group')); ?></label>
                                            <select name="group" id="group" class="p-2 rounded form-select text-uppercase">
                                                <option value="domestic">Domestic</option>
                                                <option value="overflying">Overflying</option>
                                                <option value="international">international</option>
                                                <option value="all-messages">-- All messages --</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row mb-3 custom">
                                        <div class="col-2 d-inline-flex align-items-center me-4">
                                            <label for="from" class="fw-bold me-2 mb-0 col-form-label" style="width: 50px;"><?php echo e(__('From')); ?></label>
                                            <input name="from" id="from" type="datetime-local" class="p-2 rounded form-control" placeholder="YYYY-MM-DD">
                                        </div>
                                    </div>
                                    <div class="row mb-3 custom">
                                        <div class="col-2 d-inline-flex align-items-center me-4">
                                            <label for="to" class="fw-bold me-2 mb-0 col-form-label" style="width: 52px;"><?php echo e(__('To')); ?></label>
                                            <input name="to" id="to" type="datetime-local" class="p-2 rounded form-control" placeholder="YYYY-MM-DD">
                                        </div>
                                    </div>
                                    <div class="row mb-0">
                                        <div class="col-3 d-inline-flex gap-2 buttons">
                                            <button type="submit" class="btn btn-primary text-white">
                                                <?php echo e(__('VIEW')); ?>

                                            </button>
                                            <button class="btn btn-warning text-white" type="reset">
                                                <?php echo e(__('RESET')); ?>

                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        
    </div>
    
</div>

            
        


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp3\htdocs\web\Poltekbang\resources\views/search.blade.php ENDPATH**/ ?>