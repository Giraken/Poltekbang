
<?php $__env->startSection('ats-message', 'active'); ?>
<?php $__env->startSection('content'); ?>
<link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<div class="position-relative w-100">
    <div class="container mt-5" style="margin-bottom: 20vh;">
        <div class="row justify-content-center">
            <div class="col">
                <div class="card border-0 shadow p-3" style="border-radius: 13px;">
                    <?php if(session()->has('berhasil')): ?>
                        <div class="alert alert-success la la-thumbs-up"> <?php echo e(session()->get('berhasil')); ?> </div> <?php endif; ?>
                    <h3 class="fw-bold">FPL Messages</h3>
                    <div class="card-body table-responsive">
                        <table id="yajra-datatable" class="table yajra-datatable">
                            <thead>
                            <tr>
                                <th scope="col">No.</th>
                                <th scope="col">Originator</th>
                                <th scope="col">Date/Time</th>
                                <th scope="col">Aircraft ID</th>
                                <th scope="col">REG</th>
                                <th scope="col">TYPE OF FLIGHT</th>
                                <th scope="col">DOF</th>
                                <th scope="col">Type</th>
                                <th scope="col">DEP AD</th>
                                <th scope="col">EOBT</th>
                                <th scope="col">Speed</th>
                                <th scope="col">Level</th>
                                <th scope="col">Route</th>
                                <th scope="col">DEST AD</th>
                                <th scope="col">EET</th>
                                <th scope="col">ATD</th>
                                <th scope="col">RMK</th>
                                <th scope="col">ATA</th>
                                <th scope="col">DLA</th>
                                <th scope="col">CHG</th>
                                <th scope="col">CNL</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1 ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($no++); ?></th>
                                    <th><?php echo e($d->originator); ?></th>
                                    <th><?php echo e($d->time); ?></th>
                                    <th><?php echo e($d->aircraft_id); ?></th>
                                    <th><?php echo e($d->fpl_reg); ?></th>
                                    <th><?php echo e($d->fpl_flight_type); ?></th>
                                    <th><?php echo e($d->dof); ?></th>
                                    <th>FPL</th>
                                    <th><?php echo e($d->dep_id); ?></th>
                                    <th><?php echo e($d->dof); ?></th>
                                    <th><?php echo e($d->time); ?></th>
                                    <th><?php echo e($d->fpl_cruising_speed); ?></th>
                                    <th><?php echo e($d->fpl_cruising_level); ?></th>
                                    <th><?php echo e($d->route); ?></th>
                                    <th><?php echo e($d->dest_id); ?></th>
                                    <th><?php echo e($d->fpl_eet); ?></th>
                                    <th></th>
                                    <th></th>
                                    <th><?php echo e($d->arr_time); ?></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th>
                                        <a href="/fpl-message-detail/<?php echo e($d->id); ?>" class="btn btn-secondary text-white"><i class="bi bi-search"></i></a>
                                        <a href="/downloadPDF/<?php echo e($d->id); ?>" class="btn btn-danger text-white"><i class="bi bi-file-earmark-pdf"></i></a>
                                        <a href="/filed-message/edit/<?php echo e($d->id); ?>" class="btn btn-primary text-white"><i class="bi bi-pen"></i></a>
                                        
                                        <?php if(Auth::user()->role == "admin"): ?>
                                        <a href="/delete/<?php echo e($d->id); ?>" class="btn btn-danger text-white">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                        <?php endif; ?>
                                    </th>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div style="text-align: left">
                            <button class="btn btn-primary" onclick="history.back()">
                                Back
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp3\htdocs\web\Poltekbang\resources\views/fpl-messages.blade.php ENDPATH**/ ?>