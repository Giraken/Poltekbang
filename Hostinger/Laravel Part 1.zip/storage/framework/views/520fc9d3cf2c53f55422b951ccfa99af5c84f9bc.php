
<?php $__env->startSection('ats-message', 'active'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-5" style="margin-bottom: 10rem;">
    <div class="row justify-content-center">
        <div class="col">
            <div class="card border-0 shadow" style="border-radius: 13px;">
                <div class="card-body">
                    <form method="POST" action="" style="font-family: 'Poppins', sans-serif;">
                        <?php echo csrf_field(); ?>
                        <div class="row align-items-center p-3">
                            <div class="col">
                                <h3 class="text-uppercase">View AFTN</h3>
                                <hr>
                                
                                
                                <div class="row mb-2">
                                    <div class="col d-inline-flex gap-2">
                                        <button type="reset" onclick="history.back()" class="btn btn-primary text-white ms-auto" style="">
                                            <i class="bi bi-arrow-left"></i>
                                            <?php echo e(__('BACK')); ?>

                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp3\htdocs\web\Poltekbang\resources\views/message.blade.php ENDPATH**/ ?>