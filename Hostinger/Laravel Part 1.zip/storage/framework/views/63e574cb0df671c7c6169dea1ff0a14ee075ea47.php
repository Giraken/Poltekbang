
<?php $__env->startSection('ats-message', 'active'); ?>
<?php $__env->startSection('content'); ?>
<link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<div class="position-relative w-100">
    <div class="container mt-5" style="margin-bottom: 20vh;">
        <div class="row justify-content-center">
            <div class="col">
                <div class="card border-0 shadow p-3" style="border-radius: 13px;">
                    <?php if(session()->has('berhasil')): ?>
                        <div class="alert alert-success la la-thumbs-up"> <?php echo e(session()->get('berhasil')); ?> </div> <?php endif; ?>
                    <h3 class="fw-bold">CHG Messages</h3>
                    <div class="card-body table-responsive">
                        <table id="yajra-datatable" class="table yajra-datatable">
                            <thead>
                            <tr>
                                <th scope="col">No.</th>
                                <th scope="col">Originator</th>
                                <th scope="col">Date/Time</th>
                                <th scope="col">Aircraft ID</th>
                                <th scope="col">DEP AD</th>
                                <th scope="col">ATD</th>
                                <th scope="col">DEST AD</th>
                                <th scope="col">DOF</th>
                                <th scope="col">Amendment</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1 ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($no++); ?></th>
                                    <th><?php echo e($d->originator); ?></th>
                                    <th><?php echo e($d->time); ?></th>
                                    <th><?php echo e($d->aircraft_id); ?></th>
                                    <th><?php echo e($d->dep_id); ?></th>
                                    <th></th>
                                    <th><?php echo e($d->dest_id); ?></th>
                                    <th><?php echo e($d->dof); ?></th>
                                    <th><?php echo e($d->chg_amandement); ?></th>
                                    <th>
                                        <a href="/chg-message-detail/<?php echo e($d->id); ?>" class="btn btn-secondary text-white"><i class="bi bi-search"></i></a>
                                        
                                        <?php if(Auth::user()->role == "admin"): ?>
                                        <a href="/delete/<?php echo e($d->id); ?>" class="btn btn-danger text-white">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                        <?php endif; ?>
                                    </th>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    
                            </tbody>
                        </table>
                        <div style="text-align: left">
                            <button class="btn btn-primary" onclick="history.back()">
                                Back
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u900479831/domains/fplpoltekbangsby.com/laravel/resources/views/chg-messages.blade.php ENDPATH**/ ?>