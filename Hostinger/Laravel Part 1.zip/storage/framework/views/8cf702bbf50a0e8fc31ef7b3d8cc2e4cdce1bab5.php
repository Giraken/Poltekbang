
<?php $__env->startSection('user', 'active'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .container {
        border: 1px solid;
        box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
        padding:20px;
        font-size: 20px
    }

    input[type=text], select, textarea {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 4px;
        resize: vertical;
    }

    label {
        padding: 12px 12px 12px 0;
        display: inline-block;
    }

    .col-25 {
        float: left;
        width: 25%;
        margin-top: 6px;
    }

    @media  screen and (max-width: 600px) {
        .col-25 {
            width: 100%;
            margin-top: 0;
        }
    }
</style>
<div class="position-relative w-100">
    <div class="container mt-5 shadow border-0 p-5" style="border-radius: 13px; margin-bottom: 35vh;">
        <?php if(session()->has('berhasil')): ?>
        <div class="alert alert-success la la-thumbs-up"> <?php echo e(session()->get('berhasil')); ?> </div>
        <?php elseif(session()->has('gagal')): ?>
        <div class="alert alert-danger la la-thumbs-up"> <?php echo e(session()->get('gagal')); ?> </div> <?php endif; ?>
        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?> <br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
        <p>
            <b>Account Information</b>
            <table>
                <tr>
                    <td style="width: 57%">Username </td>


                    <td style="width: 3%">:</td>

                    <td><?php echo e(Auth::user()->name); ?></td>
                </tr>
                <tr>
                    <td style="width: 57%">Originator </td>

                    <td style="width: 3%">:</td>

                    <td><?php echo e(Auth::user()->name); ?></td>
                </tr>
            </table> <br>

            <i>Use the form below to change your password.</i> <br>
            <i>New password are required to be a minimum of 6 characters in length.</i> <br> <br>

            <b>Password</b>
        </p>

        <form action="<?php echo e(route('profilPost')); ?>" method="POST"><?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-25">
                    <label for="oldpassword">Old Password :</label>
                </div>
                <div class="col-25">
                    <input type="password" class="form-control" id="oldpassword" name="oldpassword" placeholder="Enter old password">
                </div>
            </div>
            <div class="row">
                <div class="col-25">
                    <label for="password">New Password :</label>
                </div>
                <div class="col-25">
                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter new password" required autocomplete="current-password">
                </div>
            </div>
            <div class="row">
                <div class="col-25">
                    <label for="password_confirmation">Confirm New Password :</label>
                </div>
                <div class="col-25">
                    <input type="password" class="form-control" id="password_confirmation" placeholder="Re-type new password" name="password_confirmation" required autocomplete="current-password">
                </div>
            </div>


        <div class="row mb-2">
            <div class="col-3 d-inline-flex gap-2">
                <button type="submit" class="btn btn-primary text-white">
                    <?php echo e(__('SAVE')); ?>

                </button>
                <button class="btn btn-warning text-white" type="reset">
                    <?php echo e(__('RESET')); ?>

                </button>
            </div>
        </div>
    </form>
    </div>
    <div class="position-absolute bottom-0" style="left: 0; right: 0;">
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp3\htdocs\web\Poltekbang\resources\views/profil.blade.php ENDPATH**/ ?>