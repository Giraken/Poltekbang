<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    

    <!-- Scripts -->
    

    <!-- Bootstrap CSS -->
    
    

    
    

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <!-- Styles -->
    
    <title>Document</title>

    <style>
        .head {
            /* background-color: red; */
            width: 100%;
            display: flex;
            align-items: center;
            flex-direction: row;
            justify-content: center;
            gap: 0px;
            margin-bottom: 0;
            margin-top: 20px;
        }

        .head img {
            width: 70px;
        }

        .head h2 {
            font-size: 1rem;
            line-height: 0;
            margin-top: 10px !important;
            font-weight: bold;
        }

        hr {
            border: 1px solid black;
        }

        .main {
            font-weight: bold;
            /* margin-bottom: 150px; */
            /* background-color: blue; */
        }

        .main h3 {
            font-size: .8rem;
            font-weight: bold;
        }

        .main .tab1 {
            display: flex !important;
            /* background-color: red; */
        }

        table {
            border-collapse: collapse;
            text-transform: uppercase;
        }

        table td, table th {
        text-align: left;
          border: 1px solid rgb(0, 0, 0);
          padding: 8px;
          font-size: .8rem;
        }
    </style>
</head>
<body>
    <div>
        <div class="container">
            <div class="head">
                
                <img src="<?php echo $pic ?>" alt="Logo">
                
                
                <h2>Flight Plan</h2>
            </div>
            
            <div class="main">
                <h3 class="" style="text-align: center;">FREE TEXT MESSAGE</h3>
                <hr>
                <h3 class="" style="text-align: left;">AFTN HEADER</h3>
                <hr>
                <div class="tab1" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>Priority</th>
                            <th>Address</th>
                        </tr>
                        <tr>
                            <td>FF</td>
                            <td>WADDZTZX</td>
                            <td>WADDZTZX</td>
                            <td>WADDZTZX</td>
                        </tr>
                    </table>
                </div>
                
                <div class="tab2">
                    <table>
                        <tr>
                            <th>Filling Time</th>
                            <th>Originator</th>
                            <th>Originator's Reference</th>
                        </tr>
                        <tr>
                            <td>111345</td>
                            <td>WADDCTVX</td>
                            <td></td>
                        </tr>
                    </table>
                    <h3 class="">SPECIFIC IDENTIFICATION OF ADDRESSEE(S) AND/OR ORIGINATOR</h3>
                </div>
                <hr>
                <h3 class="" style="text-align: left;">FREE TEXT</h3>
                <hr>
                <div class="tab16" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>Text</th>
                        </tr>
                        <tr>
                            <td>-</td>
                        </tr>
                    </table>
                </div>
                <div class="tab16" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>Filed By</th>
                            <th>Received By</th>
                        </tr>
                        <tr>
                            <td></td>
                            <td>2022-06-11 13:45:42</td>
                        </tr>
                    </table>
                </div>
        </div>
    </div>
</body>
</html><?php /**PATH E:\xampp3\htdocs\web\Poltekbang\resources\views/pdf-freetext.blade.php ENDPATH**/ ?>