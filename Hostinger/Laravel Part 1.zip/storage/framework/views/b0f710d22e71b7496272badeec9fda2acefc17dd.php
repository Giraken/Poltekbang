<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'AirAsia.id')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/filing.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/rules.js')); ?>" defer></script>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.2/font/bootstrap-icons.css">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div id="app">
        <nav class="navbar <?php echo $__env->yieldContent('nav-position'); ?> navbar-expand-lg bg-light shadow">
            <div class="container-fluid">
                <a class="navbar-brand" href="/">
                    <img src="<?php echo e(asset('img/logo.png')); ?>" alt="logo-poltekbang" width="80">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav ms-auto align-items-center">
                        <li class="nav-item">
                            <a class="nav-link <?php echo $__env->yieldContent('beranda'); ?>" aria-current="page" href="/">Beranda</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle active <?php echo $__env->yieldContent('ats-message'); ?>" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                            ATS Message
                            </a>
                            <ul class="dropdown-menu text-center" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="/search">Search ATS Message</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="/filed-message">Filed Flight Plan(FPL)</a></li>
                            <li><a class="dropdown-item" href="/delay">Delay (DLA)</a></li>
                            <li><a class="dropdown-item" href="/modification">Modification (CHG)</a></li>
                            <li><a class="dropdown-item" href="/cancellation">Flight Plan Cancellation (CNL)</a></li>
                            <li><a class="dropdown-item" href="/departure">Departure (DEP)</a></li>
                            <li><a class="dropdown-item" href="/arrival">Arrival (ARR)</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="/free-text">Free Text ATS</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $__env->yieldContent('incoming-message'); ?>" href="/incoming-message">Incoming Message</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $__env->yieldContent('message-sent'); ?>" href="/message-sent">Message Sent</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle <?php echo $__env->yieldContent('user'); ?>" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false" data-bs-offset="10,20">
                                <?php echo e(Auth::user()->name); ?>

                            </a>
                            <ul class="dropdown-menu text-center dropdown-menu-end" aria-labelledby="navbarDropdownMenuLink">
                                
                                <?php if(Auth::user()->role == 'admin'): ?><li><a class="dropdown-item" href=<?php echo e(route('register')); ?>>Register</a></li><?php endif; ?>
                                <li><a class="dropdown-item" href="/profil">Settings</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?php echo e(Route('logout')); ?>" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">Logout</a></li>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="position-relative w-100">
            <div class="container mt-5" style="margin-bottom: 20vh;">
                <div class="row justify-content-center mb-5">
                    <div class="col">
                        <div class="card border-0 shadow" style="border-radius: 13px;">
                            <div class="card-body">
                                <h3 class="modal-title text-uppercase">View AFTN</h3>
                                <hr>
                                <div class="row justify-content-center">
                                    <div class="col">
                                        <div class="card border-0" style="border-radius: 13px;">
                                            <div class="card-body table-responsive">
                                                <table>
                                                    <tr>
                                                        <th><b>Originator</b></th>
                                                        <th>
                                                            : <?php echo e($user->name); ?>

                                                        </th>
                                                        <th></th>
                                                    </tr>
                                                    <tr>
                                                        <th><b>Date/Time</b></th>
                                                        <th>
                                                            : <?php echo e($data->time); ?>

                                                        </th>
                                                        <th></th>
                                                    </tr>
                                                    <tr>
                                                        <th><b>Aircraft ID</b></th>
                                                        <th>
                                                            : <?php echo e($data->aircraft_id); ?>

                                                        </th>
                                                        <th></th>
                                                    </tr>
                                                    <tr>
                                                        <th><b>DEP AD</b></th>
                                                        <th>
                                                            : <?php echo e($data->dep_id); ?>

                                                        </th>
                                                        <th></th>
                                                    </tr>
                                                    <tr>
                                                        <th><b>ATD</b></th>
                                                        <th>
                                                            :
                                                        </th>
                                                        <th></th>
                                                    </tr>
                                                    <tr>
                                                        <th><b>DEST AD</b></th>
                                                        <th>
                                                            : <?php echo e($data->dest_id); ?>

                                                        </th>
                                                        <th></th>
                                                    </tr>
                                                    <tr>
                                                        <th><b>DOF</b></th>
                                                        <th>
                                                            : <?php echo e($data->dof); ?>

                                                        </th>
                                                        <th></th>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <div style="text-align: right">
                                    <button class="btn btn-primary" onclick="history.back()">
                                        Back
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH /home/u900479831/domains/fplpoltekbangsby.com/laravel/resources/views/dep-message-detail.blade.php ENDPATH**/ ?>