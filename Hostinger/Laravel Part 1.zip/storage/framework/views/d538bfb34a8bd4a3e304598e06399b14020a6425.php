<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    

    <!-- Scripts -->
    

    <!-- Bootstrap CSS -->
    
    

    
    

    <!-- Fonts -->
    
    <!-- Styles -->
    
    <title>PDF</title>

    <style>
        .head {
            /* background-color: red; */
            width: 100%;
            display: flex;
            align-items: center;
            flex-direction: row;
            justify-content: center;
            gap: 0px;
            margin-bottom: 0;
            margin-top: 20px;
        }

        .head img {
            width: 70px;
        }

        .head h2 {
            font-size: 1rem;
            line-height: 0;
            margin-top: 10px !important;
            font-weight: bold;
        }

        hr {
            border: 1px solid black;
        }

        .main {
            font-weight: bold;
            /* margin-bottom: 150px; */
            /* background-color: blue; */
        }

        .main h3 {
            font-size: .8rem;
            font-weight: bold;
        }

        .main .tab1 {
            display: flex !important;
            /* background-color: red; */
        }

        table {
            border-collapse: collapse;
            text-transform: uppercase;
        }

        table td, table th {
        text-align: left;
          border: 1px solid rgb(0, 0, 0);
          padding: 8px;
          font-size: .8rem;
        }
    </style>
</head>
<body>
    <div>
        <div class="container">
            <div class="head">
                
                <img src="<?php echo $pic ?>" alt="Logo">
                
                
                <h2>Flight Plan</h2>
               
            </div>
            <hr>
            <div class="main">
                <div class="tab1">
                    <table>
                        <tr>
                            <th>Priority</th>
                            <th>Address</th>
                        </tr>
                        <tr>
                            <td><?php echo e($aftn->priority); ?></td>
                            <?php if($aftn->address1): ?>
                                <td><?php echo e($aftn->address1); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address2): ?>
                                <td><?php echo e($aftn->address2); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address3): ?>
                                <td><?php echo e($aftn->address3); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address4): ?>
                                <td><?php echo e($aftn->address4); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address5): ?>
                                <td><?php echo e($aftn->address5); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address6): ?>
                                <td><?php echo e($aftn->address6); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address7): ?>
                                <td><?php echo e($aftn->address7); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address8): ?>
                                <td><?php echo e($aftn->address8); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address9): ?>
                                <td><?php echo e($aftn->address9); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address10): ?>
                                <td><?php echo e($aftn->address10); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address11): ?>
                                <td><?php echo e($aftn->address11); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address12): ?>
                                <td><?php echo e($aftn->address12); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address13): ?>
                                <td><?php echo e($aftn->address13); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address14): ?>
                                <td><?php echo e($aftn->address14); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address15): ?>
                                <td><?php echo e($aftn->address15); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address16): ?>
                                <td><?php echo e($aftn->address16); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address17): ?>
                                <td><?php echo e($aftn->address17); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address18): ?>
                                <td><?php echo e($aftn->address18); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address19): ?>
                                <td><?php echo e($aftn->address19); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address20): ?>
                                <td><?php echo e($aftn->address20); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address21): ?>
                                <td><?php echo e($aftn->address21); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address22): ?>
                                <td><?php echo e($aftn->address22); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address23): ?>
                                <td><?php echo e($aftn->address23); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address24): ?>
                                <td><?php echo e($aftn->address24); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address25): ?>
                                <td><?php echo e($aftn->address25); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address26): ?>
                                <td><?php echo e($aftn->address26); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address27): ?>
                                <td><?php echo e($aftn->address27); ?></td>
                            <?php endif; ?>
                            <?php if($aftn->address28): ?>
                                <td><?php echo e($aftn->address28); ?></td>
                            <?php endif; ?>
                        </tr>
                    </table>
                </div>
                <hr>
                <div class="tab2">
                    <table>
                        <tr>
                            <th>Filling Time</th>
                            <th>Originator</th>
                        </tr>
                        <tr>
                            <td><?php if($aftn->filing_time): ?><?php echo e($aftn->filing_time); ?><?php endif; ?></td>
                            <td><?php if($aftn->originator): ?><?php echo e($aftn->originator); ?><?php endif; ?></td>
                        </tr>
                    </table>
                    <h3 class="">SPECIFIC IDENTIFICATION OF ADDRESSEE(S) AND/OR ORIGINATOR</h3>
                </div>
                <hr>
                <div class="tab3" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>3. Message Type</th>
                            <th>AIRCRAFT ID</th>
                            <th>8. FLIGHT RULES</th>
                            <th>TYPE OF FLIGHT</th>
                        </tr>
                        <tr>
                            <td><?php if($message->type): ?><?php echo e($message->type); ?><?php endif; ?></td>
                            <td><?php if($message->aircraft_id): ?><?php echo e($message->aircraft_id); ?><?php endif; ?></td>
                            <td><?php if($message->fpl_flight_rules): ?><?php echo e($message->fpl_flight_rules); ?><?php endif; ?></td>
                            <td><?php if($message->fpl_flight_type): ?><?php echo e($message->fpl_flight_type); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
                <div class="tab4" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>9. NUMBER</th>
                            <th>Type of aircraft</th>
                            <th>Wake turb</th>
                            <th>10.EQUIPMENT AND CAPABILITIES</th>
                        </tr>
                        <tr>
                            <td><?php if($message->fpl_number): ?><?php echo e($message->fpl_number); ?><?php endif; ?></td>
                            <td><?php if($message->fpl_aircraft_type): ?><?php echo e($message->fpl_aircraft_type); ?><?php endif; ?></td>
                            <td><?php if($message->fpl_wake_turb): ?><?php echo e($message->fpl_wake_turb); ?><?php endif; ?></td>
                            <td><?php if($message->fpl_aircraft_equipment): ?><?php echo e($message->fpl_aircraft_equipment); ?><?php endif; ?></td>
                            <td><?php if($message->fpl_surveillance_equipment): ?><?php echo e($message->fpl_surveillance_equipment); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
                <div class="tab5" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>13. DEP AD</th>
                            <th>Time</th>
                        </tr>
                        <tr>
                            <td><?php if($message->dep_id): ?><?php echo e($message->dep_id); ?><?php endif; ?></td>
                            <td><?php if($message->time): ?><?php echo e($message->time); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
                <div class="tab6" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>15. Cruising Speed</th>
                            <th>Cruising Level</th>
                            <th>Route</th>
                        </tr>
                        <tr>
                            <td><?php if($message->dep_id): ?><?php echo e($message->fpl_cruising_speed); ?><?php endif; ?></td>
                            <td><?php if($message->time): ?><?php echo e($message->fpl_cruising_level); ?><?php endif; ?></td>
                            <td><?php if($add->route): ?><?php echo e($add->route); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
                <div class="tab7" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>16. DEST AD</th>
                            <th>Total EET</th>
                            <th>1ST DEST ALTN AD</th>
                            <th>2ND DEST ALTN AD</th>
                        </tr>
                        <tr>
                            <td><?php if($message->dest_id): ?><?php echo e($message->dest_id); ?><?php endif; ?></td>
                            <td><?php if($message->fpl_eet): ?><?php echo e($message->fpl_eet); ?><?php endif; ?></td>
                            <td><?php if($message->fpl_1_altn): ?><?php echo e($message->fpl_1_altn); ?><?php endif; ?></td>
                            <td><?php if($message->fpl_2_altn): ?><?php echo e($message->fpl_2_altn); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
                <hr>
                <div class="tab8" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>STS/</th>
                            <th>PBN/</th>
                            <th>NAV/</th>
                            <th>COM/</th>
                            <th>DAT/</th>
                            <th>SUR/</th>
                        </tr>
                        <tr>
                            <td><?php if($add->STS): ?><?php echo e($add->STS); ?><?php endif; ?></td>
                            <td><?php if($add->PBN): ?><?php echo e($add->PBN); ?><?php endif; ?></td>
                            <td><?php if($add->NAV): ?><?php echo e($add->NAV); ?><?php endif; ?></td>
                            <td><?php if($add->COM): ?><?php echo e($add->COM); ?><?php endif; ?></td>
                            <td><?php if($add->DAT): ?><?php echo e($add->DAT); ?><?php endif; ?></td>
                            <td><?php if($add->SUR): ?><?php echo e($add->SUR); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
                <div class="tab9" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>DEP/</th>
                            <th>DEST/</th>
                            <th>DOF/</th>
                            <th>REG/</th>
                            <th>EET/</th>
                            <th>SEL/</th>
                        </tr>
                        <tr>
                            <td><?php if($add->DEP): ?><?php echo e($add->DEP); ?><?php endif; ?></td>
                            <td><?php if($add->DEST): ?><?php echo e($add->DEST); ?><?php endif; ?></td>
                            <td><?php if($message->dof): ?><?php echo e($message->dof); ?><?php endif; ?></td>
                            <td><?php if($add->REG): ?><?php echo e($add->REG); ?><?php endif; ?></td>
                            <td><?php if($add->EET): ?><?php echo e($add->EET); ?><?php endif; ?></td>
                            <td><?php if($add->SEL): ?><?php echo e($add->SEL); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
                <div class="tab10" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>TYPE/</th>
                            <th>CODE/</th>
                            <th>DLE/</th>
                            <th>OPR/</th>
                            <th>ORGN/</th>
                            <th>PER/</th>
                        </tr>
                        <tr>
                            <td><?php if($add->TYP): ?><?php echo e($add->TYP); ?><?php endif; ?></td>
                            <td><?php if($add->CODE): ?><?php echo e($add->CODE); ?><?php endif; ?></td>
                            <td><?php if($add->DLE): ?><?php echo e($add->DLE); ?><?php endif; ?></td>
                            <td><?php if($add->OPR): ?><?php echo e($add->OPR); ?><?php endif; ?></td>
                            <td><?php if($add->ORGN): ?><?php echo e($add->ORGN); ?><?php endif; ?></td>
                            <td><?php if($add->PER): ?><?php echo e($add->PER); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
                <div class="tab11" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>ALTN/</th>
                            <th>RALT/</th>
                            <th>TALT/</th>
                            <th>RIF/</th>
                            <th>RMK/</th>
                        </tr>
                        <tr>
                            <td><?php if($add->ALTN): ?><?php echo e($add->ALTN); ?><?php endif; ?></td>
                            <td><?php if($add->RALT): ?><?php echo e($add->RALT); ?><?php endif; ?></td>
                            <td><?php if($add->TALT): ?><?php echo e($add->TALT); ?><?php endif; ?></td>
                            <td><?php if($add->RIF): ?><?php echo e($add->RIF); ?><?php endif; ?></td>
                            <td><?php if($add->RMK): ?><?php echo e($add->RMK); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
                <hr>
                <h3 class="" style="text-align: center;">SUPPLEMENTARY INFORMATION (NOT TO BE TRANSMITTED IN FPL MESSAGES)</h3>
                <hr>
                <div class="tab12" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>Endurance</th>
                            <th>Person on board</th>
                            <th>Emergency radio</th>
                            <th>Survival equipment</th>
                            <th>Jackets</th>
                        </tr>
                        <tr>
                            <td><?php if($add->supp_endurance): ?><?php echo e($add->supp_endurance); ?><?php endif; ?></td>
                            <td><?php if($add->supp_people): ?><?php echo e($add->supp_people); ?><?php endif; ?></td>
                            <td><?php if($add->supp_radio): ?><?php echo e($add->supp_radio); ?><?php endif; ?></td>
                            <td><?php if($add->supp_survival): ?><?php echo e($add->supp_survival); ?><?php endif; ?></td>
                            <td><?php if($add->supp_jacket): ?><?php echo e($add->supp_jacket); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
                <div class="tab13" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>Number</th>
                            <th>Capacity</th>
                            <th>Cover</th>
                            <th>Colour</th>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><?php if($add->supp_cover): ?><?php echo e($add->supp_cover); ?><?php endif; ?></td>
                            <td><?php if($add->supp_color): ?><?php echo e($add->supp_color); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
                <div class="tab14" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>AIRCRAFT COLOUR AND MARKINGS</th>
                        </tr>
                        <tr>
                            <td><?php if($add->supp_aircraft_color): ?><?php echo e($add->supp_aircraft_color); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
                <div class="tab14" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>REMARKS</th>
                        </tr>
                        <tr>
                            <td><?php if($add->supp_remark): ?><?php echo e($add->supp_remark); ?><?php endif; ?></td>
                            <td><?php if($add->supp_remark_desc): ?><?php echo e($add->supp_remark_desc); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
                <div class="tab15" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>Pilot in command</th>
                        </tr>
                        <tr>
                            <td><?php if($add->supp_pilot): ?><?php echo e($add->supp_pilot); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
                <div class="tab16" style="margin-bottom: 20px;">
                    <table>
                        <tr>
                            <th>Filed By</th>
                            <th>SPACE RESERVED FOR ADDITIONAL REQUIREMENTS</th>
                            <th>Received By</th>
                        </tr>
                        <tr>
                            <td><?php if($message->filed_by): ?><?php echo e($message->filed_by); ?><?php endif; ?></td>
                            <td><?php if($add->supp_reserved): ?><?php echo e($add->supp_reserved); ?><?php endif; ?></td>
                            <td><?php if($add->created_at): ?><?php echo e($add->created_at); ?><?php endif; ?></td>
                        </tr>
                    </table>
                </div>
        </div>
    </div>
</body>
</html><?php /**PATH /home/u900479831/domains/fplpoltekbangsby.com/laravel/resources/views/pdf.blade.php ENDPATH**/ ?>