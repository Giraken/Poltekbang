
<?php $__env->startSection('ats-message', 'active'); ?>
<?php $__env->startSection('content'); ?>
<div class="position-relative w-100">
    <div class="container mt-5" style="margin-bottom: 20vh;">
        <div class="row justify-content-center mb-5">
            <div class="col">
                <div class="card border-0 shadow" style="border-radius: 13px;">
                    <div class="card-body">
                        <h3 class="modal-title text-uppercase">View AFTN</h3>
                        <hr>
                        <div class="row justify-content-center">
                            <div class="col">
                                <div class="card border-0" style="border-radius: 13px;">
                                    <div class="card-body table-responsive">
                                        <table>
                                            <tr>
                                                <th><b>Originator</b></th>
                                                <th>
                                                    : <?php echo e($user->name); ?>

                                                </th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th><b>Date/Time</b></th>
                                                <th>
                                                    : <?php echo e($data->time); ?>

                                                </th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th><b>Aircraft ID</b></th>
                                                <th>
                                                    : <?php echo e($data->aircraft_id); ?>

                                                </th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th><b>DEP AD</b></th>
                                                <th>
                                                    : <?php echo e($data->dep_id); ?>

                                                </th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th><b>ATD</b></th>
                                                <th>
                                                    : <?php echo e($data->arr_id); ?>

                                                </th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th><b>DEST AD</b></th>
                                                <th>
                                                    : <?php echo e($data->dest_id); ?>

                                                </th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th><b>Arrival Aerodrome</b></th>
                                                <th>
                                                    :<?php echo e($data->arr_aerodrome); ?>

                                                </th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th><b>ATA</b></th>
                                                <th>
                                                    : <?php echo e($data->arr_time); ?>

                                                </th>
                                                <th></th>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div style="text-align: right">
                            <button class="btn btn-primary" onclick="history.back()">
                                Back
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="position-absolute bottom-0" style="left: 0; right: 0;">
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp3\htdocs\web\Poltekbang\resources\views/arr-message-detail.blade.php ENDPATH**/ ?>