<div class="d-flex bg-black justify-content-center align-items-center p-3 text-white">
  <div>
      © Copyright Poltekbang 2022
  </div>
</div>
<?php /**PATH /home/u900479831/domains/fplpoltekbangsby.com/laravel/resources/views/layouts/footer.blade.php ENDPATH**/ ?>